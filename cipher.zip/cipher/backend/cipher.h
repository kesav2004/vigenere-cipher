#ifndef CIPHER_H
#define CIPHER_H

#include <string>

std::string encryptDecrypt(const std::string &text, const std::string &key, bool encrypt);

#endif
