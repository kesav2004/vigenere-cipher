#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

// Function to generate the key in a cyclic manner to match the length of the text
string generateKey(const string& text, const string& key) {
    string extendedKey = key;
    int x = text.size();
    for (int i = 0; extendedKey.size() < x; ++i) {
        extendedKey.push_back(key[i % key.size()]);
    }
    return extendedKey;
}

// Function to encrypt the text using the Vigenère cipher
string encryptText(const string& text, const string& key) {
    string cipher_text;
    for (int i = 0; i < text.size(); ++i) {
        // Corrected formula to ensure result stays within 'A'-'Z' range
        char x = ((text[i] - 'A') + (key[i] - 'A')) % 26 + 'A';
        cipher_text.push_back(x);
    }
    return cipher_text;
}

// Function to decrypt the text using the Vigenère cipher
string decryptText(const string& cipher_text, const string& key) {
    string orig_text;
    for (int i = 0; i < cipher_text.size(); ++i) {
        // Corrected formula to ensure result stays within 'A'-'Z' range
        char x = ((cipher_text[i] - 'A') - (key[i] - 'A') + 26) % 26 + 'A';
        orig_text.push_back(x);
    }
    return orig_text;
}

int main(int argc, char* argv[]) {
    // Ensure correct number of arguments
    if (argc != 4) {
        cerr << "Usage: cipher.exe <text> <key> <mode>\n";
        cerr << "mode: 1 for encryption, 0 for decryption\n";
        return 1;
    }

    // Extract command-line arguments
    string text = argv[1];
    string key = argv[2];
    bool encryptMode = string(argv[3]) == "1";

    // Convert text and key to uppercase for consistency
    transform(text.begin(), text.end(), text.begin(), ::toupper);
    transform(key.begin(), key.end(), key.begin(), ::toupper);

    // Generate the extended key to match the text length
    string extendedKey = generateKey(text, key);

    // Encrypt or decrypt based on the mode
    string result;
    if (encryptMode) {
        result = encryptText(text, extendedKey);
    } else {
        result = decryptText(text, extendedKey);
    }

    // Output the result to standard output
    cout << result << endl;

    return 0;
}
