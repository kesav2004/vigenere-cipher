function processCipher() {
    const inputText = document.getElementById('inputText').value;
    const key = document.getElementById('key').value;
    const mode = document.getElementById('mode').value;
  
    fetch(`http://localhost:3000/cipher`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ inputText, key, mode })
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Server error: ' + response.status);
      }
      return response.json();
    })
    .then(data => {
      console.log('Server response:', data);
      document.getElementById('outputText').value = data.result || 'Error: No result';
    })
    .catch(error => {
      console.error('Error:', error);
      document.getElementById('outputText').value = 'Error: ' + error.message;
    });
  }
  