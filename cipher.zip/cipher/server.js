const express = require('express');
const { exec, execSync } = require('child_process');
const app = express();

app.use(express.json());
app.use(express.static('frontend'));

// Compile the C++ code when the server starts (only if necessary)
try {
  execSync('g++ -mconsole -o cipher.exe backend/cipher.cpp');
  console.log('C++ code compiled successfully');
} catch (error) {
  console.error('Error compiling C++ code:', error.message);
  process.exit(1); // Exit if compilation fails
}

app.post('/cipher', (req, res) => {
  const { inputText, key, mode } = req.body;
  const encrypt = mode === 'encrypt' ? '1' : '0';

  // Command to execute the C++ program
  const command = `.\\cipher.exe "${inputText}" "${key}" ${encrypt}`;
  console.log('Executing command:', command);

  exec(command, (error, stdout, stderr) => {
    if (error) {
      console.error('Execution error:', error.message);
      console.error('stderr output:', stderr);
      res.status(500).json({ error: 'Cipher execution error: ' + stderr });
      return;
    }
    console.log('stdout output:', stdout.trim());
    res.json({ result: stdout.trim() });
  });
});

// Start the server
app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});
